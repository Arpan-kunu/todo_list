const router = require("express").Router();
const User = require("../Models/users");
const List = require("../Models/list");

// Create
router.post("/addTask", async (req, res) => {
  try {
    const { title, body, email } = req.body;
    const existingUser = await User.findOne({ user_email: email });

    if (existingUser) {
      const list = new List({ title, body, user: existingUser });

      await list.save();

      existingUser.list.push(list);
      await existingUser.save();

      // Send the response and return to terminate the function
      return res.status(200).json({ list });
    } else {
      // Send the response and return to terminate the function
      return res.status(404).json({ error: "User not found" });
    }
  } catch (error) {
    console.log(error);

    // Send an error response and return to terminate the function
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

// Update
router.put("/updateTask/:id", async (req, res) => {
  try {
    const { title, body, email } = req.body;
    const existingUser = await User.findOne({ user_email: email });

    if (existingUser) {
      // Find and update the task
      const list = await List.findByIdAndUpdate(req.params.id, { title, body }, { new: true });

      if (!list) {
        return res.status(404).json({ error: "Task not found" });
      }

      res.status(200).json({ list });
    } else {
      res.status(404).json({ error: "User not found" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

//Delete
router.delete("/deleteTask/:id", async (req, res) => {
    try {
        const {email} = req.body
      const existingUser = await User.findByIdAndUpdate({ user_email: email },
        { $pull : {list : req.params.id}});
      if (existingUser) {
        const list = await List.findByIdAndDelete(req.params.id).then(() => 
        res.status(200).json({ message: "Task Deleted"})
        );
      } 
    } catch (error) {
      console.log(error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });

  //getTask
  router.get("/getTasks/:id", async (req, res) => {
    try {
      const existingUser = await User.findById(req.params.id);
      
      if (!existingUser) {
        return res.status(404).json({ error: "User not found" });
      }
      const tasks = await List.find({ user: existingUser._id });
      if(tasks.length !== 0) {
        res.status(200).json({ tasks });
      } else {
        res.status(200).json({ message: "No Tasks" })
      }
    } catch (error) {
      console.log(error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });

module.exports = router;
