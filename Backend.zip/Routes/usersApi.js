const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const jwt = require('jsonwebtoken');
const User = require("../Models/users");

// http://localhost:5000/api/user/register
router.post("/register", async (req, res) => {
  try {
    const { user_name, user_email, password } = req.body;
    const saltRounds = 10;
    const hashPassword = await bcrypt.hash(password, saltRounds);

    const newUser = new User({
      user_name,
      user_email,
      password: hashPassword, 
      tokenVersion: 0, // Add tokenVersion when registering a new user
    });

    const savedUser = await newUser.save();
    res.json(savedUser);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// SIGN IN
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    // Check if email is defined before calling trim()
    const user = await User.findOne({ user_email: email && email.trim() });

    if (!user) {
      return res.status(400).json({ message: "Please Sign Up First" });
    }

    const isPasswordCorrect = await bcrypt.compare(password, user.password);
    if (!isPasswordCorrect) {
      return res.status(400).json({ message: "Incorrect Password" });
    }

    // Increment token version and save it to the database
    user.tokenVersion += 1;
    await user.save();

    const token = jwt.sign(
      { userId: user._id, userEmail: user.user_email, tokenVersion: user.tokenVersion },
      "this is dummy text",
      { expiresIn: '1h' }
    );

    const { password: userPassword, ...userWithoutPassword } = user._doc;

    res.status(200).json({ token, user: userWithoutPassword });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// LOGOUT FROM ALL DEVICES
router.post("/logout-all", async (req, res) => {
  try {
    // Get user ID from the token
    const userId = req.userId; // Assuming you have middleware to extract the user ID from the token

    // Find the user and increment the token version
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    user.tokenVersion += 1;
    await user.save();

    res.status(200).json({ message: 'Logged out from all devices' });
  } catch (error) {
    console.error('Logout-all error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

module.exports = router;
