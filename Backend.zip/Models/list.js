const mongoose = require("mongoose");
const listSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true,
    },
    body: {
        type: String,
        require: true
    },
    list: [{
        type: mongoose.Types.ObjectId,
        ref: "List",
    }]
})

module.exports = mongoose.model("List",listSchema)


// list.js

