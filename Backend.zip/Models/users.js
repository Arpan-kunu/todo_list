const mongoose = require("mongoose")

const userSchema = new mongoose.Schema({
    user_name: {
        type:String,
    },
    user_email: {
        type: String,
        required: true,
    },
    password: {
        type: String,
        
       
    },
    tokenVersion: {
        type: Number,
        default: 0,
      },
    list: [{
        type: mongoose.Types.ObjectId,
        ref: "List",
    }],
});

module.exports = mongoose.model("todoList_users",userSchema)