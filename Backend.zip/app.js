const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const db = require("./db");
const userRoute = require("./Routes/usersApi");
const listRoute = require("./Routes/list");  // Renamed to avoid confusion

const app = express();

app.use(bodyParser.json());
app.use(cors());

app.use("/api/user", userRoute);
app.use("/api/list", listRoute);

const Port = process.env.PORT || 5000;

app.get("/", (req, res) => {
  res.send("Hello World from Server");
});

app.listen(Port, () => {
  console.log(`Server is Running on : http://localhost:${Port}`);
});
