import React, { useState, useEffect } from 'react';
import './todo.css';
import { Link } from 'react-router-dom';

const Todo = () => {
  const [todos, setTodos] = useState([]);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [user, setUser] = useState(null);

  useEffect(() => {
    // Fetch tasks when the component mounts
    getTasks();

    // Retrieve user details from local storage
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const getTasks = async () => {
    // Fetch tasks using the API endpoint
    try {
      const response = await fetch(`http://localhost:5000/api/user/getTasks/${user?.id}`);
      const data = await response.json();

      if (response.ok) {
        setTodos(data.tasks);
      } else {
        console.error('Failed to fetch tasks:', data.error);
      }
    } catch (error) {
      console.error('Unexpected error during task fetch:', error);
    }
  };

  const addTodo = async () => {
    if (user) {
      if (title && body) {
        try {
          const response = await fetch('http://localhost:5000/api/user/addTask', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ title, body, email: user.user_email }),
          });

          if (response.ok) {
            const data = await response.json();
            console.log("Task Set Successfully")
            setTodos([...todos, data.list]);
            setTitle('');
            setBody('');
          } else {
            console.error('Failed to add todo:', response.statusText);
          }
        } catch (error) {
          console.error('Unexpected error during todo addition:', error);
        }
      }
    } else {
      alert('Please log in to add a todo.');
    }
  };

  

  const deleteTodo = async (id) => {
    try {
      const response = await fetch(`http://localhost:5000/api/user/deleteTask/${id}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email: user.user_email }),
      });

      if (response.ok) {
        setTodos(todos.filter((todo) => todo._id !== id));
      } else {
        console.error('Failed to delete todo:', response.statusText);
      }
    } catch (error) {
      console.error('Unexpected error during todo deletion:', error);
    }
  };

  const editTodo = (todo) => {
    setTitle(todo.title);
    setBody(todo.body);
  };

  return (
    <div className="todo">
      <div className="todo-main container d-flex justify-content-center align-items-center">
        {user ? (
          <div className="d-flex flex-column todo-inputs-div w-50">
            <input
              type="text"
              placeholder="TITLE"
              className="my-2 todo-inputs"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
            <textarea
              placeholder="BODY"
              className="p-2 todo-inputs"
              value={body}
              onChange={(e) => setBody(e.target.value)}
            />
            <button type="button" onClick={addTodo} className="btn btn-primary mt-2">
              Add Todo
            </button>
          </div>
        ) : (
          <div>
            <p>Please log in to add a todo.</p>
            {localStorage.length === 0 && (
              <Link to="/signIn" className="btn btn-primary">
                Log In
              </Link>
            )}
          </div>
        )}
      </div>
      <TodoList todos={todos} deleteTodo={deleteTodo} editTodo={editTodo} />
    </div>
  );
};

const TodoList = ({ todos, deleteTodo, editTodo }) => {
  return (
    <div className="todo-list container mt-4">
      <h2>Todo List</h2>
      <ul className="list-group">
        {todos.map((todo) => (
          <li key={todo._id} className="list-group-item d-flex justify-content-between align-items-center">
            <div>
              <strong>{todo.title}</strong>: {todo.body}
            </div>
            <div>
              <button
                type="button"
                onClick={() => editTodo(todo)}
                className="btn btn-warning btn-sm mr-2"
              >
                Edit
              </button>
              <button
                type="button"
                onClick={() => deleteTodo(todo._id)}
                className="btn btn-danger btn-sm"
              >
                Delete
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Todo;
