import React from 'react';
import "./About.css"

const About = () => {
  return (
    <div className='about d-flex justify-content-center alignItem-center'>
        <div className='container'>
        <h1>About Us</h1>
      <p>Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups& Lorem ipsum is placeholder text commonly used in the graphic, print,<br/> and publishing industries for previewing layouts and visual mockups!Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups
      </p>
        </div>
   
    </div>
  )
}

export default About
