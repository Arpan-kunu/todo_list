import React from 'react'

const footer = () => {
  return (
    <div className='container-fluid p-3 d-flex justify-content-center align-items-center text footer'>
      <h4>Todo</h4> &nbsp;<p className='m-0'>&copy;THE TODO-LIST</p>
    </div>
  )
}

export default footer
