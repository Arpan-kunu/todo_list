import React,{useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'jquery/dist/jquery.min.js';
import 'popper.js/dist/umd/popper.min.js';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import "./Navbar.css";
import { Link } from 'react-router-dom';
import UserProfile from '../UserProfile'; // Import the UserProfile component


const Navbar = () => {

    const [showProfile, setShowProfile] = useState(false);

    const user = JSON.parse(localStorage.getItem('user'));
  
    const handleProfileClick = () => {
      setShowProfile(true);
    };
  
    const closeProfile = () => {
      setShowProfile(false);
    };
  
    const handleLogout = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/user/logout-all', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${user.token}`, // Add the user token to the headers
          },
        });
  
        if (response.ok) {
          // Clear user data from local storage
          localStorage.removeItem('user');
          // Redirect to the home page or login page
          window.location.href = '/signIn';
        } else {
          console.error('Logout failed:', response.statusText);
        }
      } catch (error) {
        console.error('Unexpected error during logout:', error);
      }
    };
  
  return (
    <div>
      <nav className="navbar navbar-expand-lg ">
        <div className="container">
          <Link className="navbar-brand" to="/">
            <b>   
                TODO</b>
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
              <li className="nav-item mx-2">
                <Link className="nav-link active" aria-current="page" to="/">
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link active" aria-current="page" to="/about">
                  About Us
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link active" aria-current="page" to="/todo">
                  todo
                </Link>
              </li>
              <li className="nav-item mx-2">
                <Link className="nav-link active btn-nav" aria-current="page" to="/signUp">
                  Sign Up
                </Link>
              </li>
              <li className="nav-item mx-2">
                <Link className="nav-link active btn-nav" aria-current="page" to="/signIn">
                  Sign In
                </Link>
              </li>
               <li className="nav-item mx-2">
              <Link className="nav-link active btn-nav" onClick={handleLogout} to="#">
                Log Out
              </Link>
            </li>
              <li className="nav-item">
          <button onClick={handleProfileClick} className="nav-link active" aria-current="page">
            <img className="img-fluid user-png" src="https://tse1.mm.bing.net/th?id=OIP.k7dE2dftQijg3KbpTyIObAHaHa&pid=Api&rs=1&c=1&qlt=95&w=116&h=116" alt="useriimg"/>
          </button>
        </li>
            </ul>
            {/* Display user profile if user is logged in */}
      {user && <UserProfile user={user} />}
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
