
import React from 'react';

const UserProfile = ({ user, onClose }) => {
  return (
    <div className="user-profile">
     
      <h3>User Profile</h3>
      <p>
        <strong>Username:</strong> {user.user_name}
      </p>
      <p>
        <strong>Email:</strong> {user.user_email}
      </p>
    </div>
  );
};

export default UserProfile;