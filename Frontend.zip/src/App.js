import Navbar from "./Components/Navbar/Navbar";
import About from "./Components/About/About"
import Footer from "./Components/Footer/footer";
import {BrowserRouter as Router, Routes,Route} from "react-router-dom";
import Home from "./Components/Home/Home";
import SignUp from "./Components/SignUp/SignUp";
import SignIn from "./Components/SignIn/SignIn";
import Todo from "./Components/Todo/todo"

function App() {
  return (
    <div>
      <Router>
      <Navbar/>
        <Routes>
          <Route exact path="/" element={<Home/>}/>
          <Route path="/about" element={<About/>}/>
          <Route path="/todo" element={<Todo/>}/>
          <Route path="/signUp" element={<SignUp/>}/>
          <Route path="/signIn" element={<SignIn/>}/>
        </Routes>
      </Router> 
      <Footer/>
    </div>
  );
}
export default App;
